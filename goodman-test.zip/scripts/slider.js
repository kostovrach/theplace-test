new Swiper(".slider", {
  loop: true,
  spaceBetween: 50,
  pagination: {
    el: ".slider__pagination",
  },
  autoplay: {
    delay: 7000,
  },
});
